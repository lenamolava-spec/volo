const Database=require("better-sqlite3");
const bcrypt=require("bcryptjs");
const db=new Database("volo.db");
const email=process.env.ADMIN_EMAIL||"admin@volo.local";
const password=process.env.ADMIN_PASSWORD||"ChangeMe_123!";
const hash=bcrypt.hashSync(password,12);
db.prepare(`INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'admin')
ON CONFLICT(email) DO UPDATE SET password_hash=excluded.password_hash,role='admin'`).run("Volo Admin",email,hash);
console.log("Admin:",email,"Password:",password);
