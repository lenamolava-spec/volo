// Optional full-stack client API helpers for volo.
const VoloAPI = {
  token: localStorage.getItem("voloToken"),
  headers(){ return this.token ? {"Authorization":"Bearer "+this.token} : {}; },
  async request(url, options={}){
    options.headers={...(options.headers||{}),...this.headers()};
    const r=await fetch(url,options); const data=await r.json().catch(()=>({}));
    if(!r.ok) throw new Error(data.error||"Ошибка сервера"); return data;
  },
  async register(name,email,password){const x=await this.request("/api/auth/register",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name,email,password})});this.token=x.token;localStorage.setItem("voloToken",x.token);return x.user},
  async login(email,password){const x=await this.request("/api/auth/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email,password})});this.token=x.token;localStorage.setItem("voloToken",x.token);return x.user},
  logout(){this.token=null;localStorage.removeItem("voloToken")},
  listings(params=""){return this.request("/api/listings"+params)},
  createListing(formData){return this.request("/api/listings",{method:"POST",body:formData})},
  favorite(id){return this.request("/api/listings/"+id+"/favorite",{method:"POST"})},
  favorites(){return this.request("/api/favorites")},
  messages(){return this.request("/api/messages")},
  sendMessage(receiverId,listingId,body){return this.request("/api/messages",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({receiverId,listingId,body})})}
};
