# volo — полноценная серверная версия

Это следующая версия volo: Node.js + Express + SQLite.

## Запуск на компьютере

Требуется Node.js 18+.

```bash
npm install
npm start
```

Откройте `http://localhost:3000`.

Для разработки:
```bash
npm run dev
```

## Что добавлено

- реальная SQLite-база `volo.db`;
- регистрация и вход;
- хеширование паролей;
- JWT-сессии;
- пользователи и роли;
- создание объявлений;
- загрузка изображений до 8 МБ;
- поиск, категории и сортировка через API;
- избранное;
- сообщения между пользователями;
- удаление собственных объявлений;
- API статистики администратора;
- health-check `/api/health`.

## Переменные

Скопируйте `.env.example` в `.env` и задайте длинный `JWT_SECRET`.
В продакшене обязательно используйте HTTPS и секрет, который не хранится в репозитории.

## API

- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/me`
- `GET /api/listings`
- `GET /api/listings/:id`
- `POST /api/listings`
- `DELETE /api/listings/:id`
- `POST /api/listings/:id/favorite`
- `GET /api/favorites`
- `GET /api/messages`
- `POST /api/messages`
- `GET /api/admin/stats`
- `GET /api/health`

Фронтенд из предыдущей версии сохранён. `api.js` содержит готовый клиент для подключения интерфейса к API.
