const listings=[
{id:1,title:"BMW 3 серии, 2020",price:2450000,city:"Москва",time:"Сегодня, 12:34",cat:"Транспорт",tag:"Проверенный продавец",img:"https://images.unsplash.com/photo-1555215695-3004980ad54e?auto=format&fit=crop&w=800&q=80"},
{id:2,title:"iPhone 14 Pro, 256 ГБ",price:89990,city:"Санкт-Петербург",time:"Сегодня, 11:20",cat:"Электроника",tag:"С доставкой",img:"https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?auto=format&fit=crop&w=800&q=80"},
{id:3,title:"2-комнатная квартира, 58 м²",price:8500000,city:"Казань",time:"Сегодня, 10:15",cat:"Недвижимость",tag:"Собственник",img:"https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=800&q=80"},
{id:4,title:"Угловой диван, новый",price:32000,city:"Екатеринбург",time:"Сегодня, 09:42",cat:"Для дома и дачи",tag:"С доставкой",img:"https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=800&q=80"},
{id:5,title:"Горный велосипед Merida",price:24000,city:"Новосибирск",time:"Вчера, 21:17",cat:"Транспорт",tag:"Торг уместен",img:"https://images.unsplash.com/photo-1571068316344-75bc76f77890?auto=format&fit=crop&w=800&q=80"},
{id:6,title:"Sony PlayStation 5",price:44990,city:"Краснодар",time:"Вчера, 19:03",cat:"Электроника",tag:"С доставкой",img:"https://images.unsplash.com/photo-1606813907291-d86efa9b94db?auto=format&fit=crop&w=800&q=80"},
{id:7,title:"Щенки золотистого ретривера",price:25000,city:"Самара",time:"Вчера, 17:36",cat:"Животные",tag:"Документы",img:"https://images.unsplash.com/photo-1552053831-71594a27632d?auto=format&fit=crop&w=800&q=80"},
{id:8,title:"Дача, 6 соток",price:1200000,city:"Тюмень",time:"Вчера, 15:12",cat:"Недвижимость",tag:"Собственник",img:"https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80"}
];
const cats=[["🚗","Транспорт"],["⌂","Недвижимость"],["▣","Электроника"],["▰","Бытовая техника"],["♟","Одежда и обувь"],["▱","Для дома и дачи"],["🐾","Животные"],["▣","Работа"],["%","Услуги"],["•••","Другое"]];
let selectedCat="", favorites=JSON.parse(localStorage.getItem("voloFav")||"[]");

function money(n){return new Intl.NumberFormat("ru-RU").format(n)+" ₽"}
function init(){
  document.getElementById("categories").innerHTML=cats.map((c,i)=>`<div class="cat" onclick="selectCat('${c[1]}')" data-cat="${c[1]}"><span class="ico">${c[0]}</span><small>${c[1]}</small></div>`).join("");
  document.getElementById("categoryGrid").innerHTML=cats.map(c=>`<div class="category-item" onclick="selectCat('${c[1]}')"><span class="ico">${c[0]}</span><div><b>${c[1]}</b><small>${Math.floor(Math.random()*1800000+12000).toLocaleString("ru-RU")} объявлений</small></div></div>`).join("");
  renderRecent();renderListings();
}
function renderListings(){
 let q=(document.getElementById("search").value||"").toLowerCase().trim();
 let data=listings.filter(x=>(!selectedCat||x.cat===selectedCat)&&(!q||(x.title+" "+x.city+" "+x.cat).toLowerCase().includes(q)));
 const sort=document.getElementById("sort").value;
 if(sort==="cheap")data.sort((a,b)=>a.price-b.price); if(sort==="expensive")data.sort((a,b)=>b.price-a.price);
 document.getElementById("cards").innerHTML=data.map(card).join("");
 document.getElementById("empty").classList.toggle("hidden",data.length>0);
 const af=document.getElementById("activeFilter");af.classList.toggle("hidden",!selectedCat);if(selectedCat)af.innerHTML=`${selectedCat}<button onclick="selectCat('')">×</button>`;
 document.querySelectorAll(".cat").forEach(e=>e.classList.toggle("selected",e.dataset.cat===selectedCat));
}
function card(x){let on=favorites.includes(x.id);return `<article class="card" onclick="openListing(${x.id})"><div class="photo"><img src="${x.img}" alt="${x.title}" loading="lazy"><button class="heart ${on?"on":""}" onclick="event.stopPropagation();toggleFav(${x.id})">${on?"♥":"♡"}</button></div><h3>${x.title}</h3><div class="price">${money(x.price)}</div><div class="meta">${x.city}<br>${x.time}</div><span class="tag">${x.tag}</span></article>`}
function selectCat(c){selectedCat=c;renderListings();document.getElementById("listings")?.scrollIntoView({behavior:"smooth"})}
function toggleFav(id){favorites=favorites.includes(id)?favorites.filter(x=>x!==id):[...favorites,id];localStorage.setItem("voloFav",JSON.stringify(favorites));document.getElementById("favCount").textContent=favorites.length;renderListings();toast(favorites.includes(id)?"Добавлено в избранное":"Удалено из избранного")}
function toggleFavorites(){let f=listings.filter(x=>favorites.includes(x.id));if(!f.length){toast("В избранном пока ничего нет");return}document.getElementById("cards").innerHTML=f.map(card).join("");document.querySelector(".section-head h1").textContent="Избранное";window.scrollTo({top:180,behavior:"smooth"})}
function renderRecent(){document.getElementById("recent").innerHTML=listings.slice(1,5).map(x=>`<div class="recent"><img src="${x.img}"><div><b>${x.title}</b><small>${money(x.price)}</small></div></div>`).join("")}
function clearFilters(){selectedCat="";document.getElementById("search").value="";document.getElementById("sort").value="popular";document.querySelector(".section-head h1").textContent="Популярные объявления";renderListings()}
function openListing(id){let x=listings.find(y=>y.id===id);document.getElementById("modalBox").innerHTML=`<button class="close" onclick="closeModal()">×</button><img src="${x.img}" style="width:100%;height:280px;object-fit:cover;border-radius:12px"><h2>${x.title}</h2><div style="font-size:25px;font-weight:800">${money(x.price)}</div><p style="color:#666">${x.city} · ${x.time}</p><p>Продавец разместил объявление на volo. Здесь будет полное описание товара, характеристики и условия сделки.</p><div class="form-actions"><button class="secondary" onclick="toggleFav(${x.id});closeModal()">♡ В избранное</button><button class="primary" onclick="toast('Сообщение продавцу создано');closeModal()">Написать продавцу</button></div>`;document.getElementById("modal").classList.remove("hidden")}
function openAuth(){document.getElementById("modalBox").innerHTML=`<h2>Вход в volo</h2><p style="color:#666">Войдите, чтобы размещать объявления и общаться с продавцами.</p><div class="form"><input placeholder="Телефон или email"><input type="password" placeholder="Пароль"><div class="form-actions"><button class="secondary" onclick="closeModal()">Отмена</button><button class="primary" onclick="toast('Добро пожаловать в volo');closeModal()">Войти</button></div></div>`;document.getElementById("modal").classList.remove("hidden")}
function openSell(){document.getElementById("modalBox").innerHTML=`<h2>Новое объявление</h2><div class="form"><input id="newTitle" placeholder="Название объявления"><input id="newPrice" type="number" placeholder="Цена, ₽"><select><option>Транспорт</option><option>Недвижимость</option><option>Электроника</option><option>Для дома и дачи</option><option>Одежда и обувь</option><option>Животные</option><option>Услуги</option></select><textarea placeholder="Описание"></textarea><input type="file" accept="image/*"><div class="form-actions"><button class="secondary" onclick="closeModal()">Отмена</button><button class="primary" onclick="publish()">Опубликовать</button></div></div>`;document.getElementById("modal").classList.remove("hidden")}
function publish(){let t=document.getElementById("newTitle").value,p=document.getElementById("newPrice").value;if(!t||!p){toast("Заполните название и цену");return}toast("Объявление опубликовано");closeModal()}
function closeModal(){document.getElementById("modal").classList.add("hidden")}
function toast(s){let t=document.getElementById("toast");t.textContent=s;t.classList.add("show");clearTimeout(window.tt);window.tt=setTimeout(()=>t.classList.remove("show"),2200)}
function goHome(){clearFilters();window.scrollTo({top:0,behavior:"smooth"})}
init();document.getElementById("favCount").textContent=favorites.length;
