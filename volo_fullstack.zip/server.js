const express = require("express");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const multer = require("multer");
const Database = require("better-sqlite3");

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "CHANGE_ME_IN_PRODUCTION";
const ROOT = __dirname;
const UPLOADS = path.join(ROOT, "uploads");
fs.mkdirSync(UPLOADS, { recursive: true });

const db = new Database(path.join(ROOT, "volo.db"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'user',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS listings (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 title TEXT NOT NULL,
 description TEXT NOT NULL DEFAULT '',
 price INTEGER NOT NULL,
 city TEXT NOT NULL DEFAULT 'Россия',
 category TEXT NOT NULL,
 image TEXT,
 status TEXT NOT NULL DEFAULT 'active',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS favorites (
 user_id INTEGER NOT NULL,
 listing_id INTEGER NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(user_id, listing_id),
 FOREIGN KEY(user_id) REFERENCES users(id),
 FOREIGN KEY(listing_id) REFERENCES listings(id)
);
CREATE TABLE IF NOT EXISTS messages (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 sender_id INTEGER NOT NULL,
 receiver_id INTEGER NOT NULL,
 listing_id INTEGER,
 body TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 read_at TEXT,
 FOREIGN KEY(sender_id) REFERENCES users(id),
 FOREIGN KEY(receiver_id) REFERENCES users(id)
);
`);

app.use(express.json({limit:"2mb"}));
app.use(express.urlencoded({extended:true}));
app.use("/uploads", express.static(UPLOADS));
app.use(express.static(ROOT));

const upload = multer({
  storage: multer.diskStorage({
    destination: (_,__,cb)=>cb(null, UPLOADS),
    filename: (_,file,cb)=>{
      const ext = path.extname(file.originalname).toLowerCase();
      cb(null, crypto.randomUUID()+ext);
    }
  }),
  limits:{fileSize: 8*1024*1024},
  fileFilter: (_,file,cb)=>cb(null, /^image\/(jpeg|png|webp|gif)$/.test(file.mimetype))
});

function tokenFor(user){ return jwt.sign({id:user.id,role:user.role}, JWT_SECRET,{expiresIn:"7d"}); }
function auth(req,res,next){
  const h=req.headers.authorization||"";
  if(!h.startsWith("Bearer ")) return res.status(401).json({error:"Требуется авторизация"});
  try { req.user=jwt.verify(h.slice(7),JWT_SECRET); next(); }
  catch { res.status(401).json({error:"Сессия истекла"}); }
}
function optionalAuth(req,_,next){
  const h=req.headers.authorization||"";
  if(h.startsWith("Bearer ")) try{req.user=jwt.verify(h.slice(7),JWT_SECRET)}catch{}
  next();
}

app.post("/api/auth/register", async (req,res)=>{
  const {name,email,password}=req.body;
  if(!name||!email||!password||password.length<6) return res.status(400).json({error:"Имя, email и пароль от 6 символов обязательны"});
  try{
    const hash=await bcrypt.hash(password,12);
    const info=db.prepare("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)").run(name,email.toLowerCase(),hash);
    const user=db.prepare("SELECT id,name,email,role FROM users WHERE id=?").get(info.lastInsertRowid);
    res.json({user,token:tokenFor(user)});
  }catch(e){res.status(409).json({error:"Пользователь с таким email уже существует"});}
});
app.post("/api/auth/login", async (req,res)=>{
  const {email,password}=req.body;
  const user=db.prepare("SELECT * FROM users WHERE email=?").get((email||"").toLowerCase());
  if(!user || !(await bcrypt.compare(password||"",user.password_hash))) return res.status(401).json({error:"Неверный email или пароль"});
  res.json({user:{id:user.id,name:user.name,email:user.email,role:user.role},token:tokenFor(user)});
});
app.get("/api/me",auth,(req,res)=>{
  res.json(db.prepare("SELECT id,name,email,role,created_at FROM users WHERE id=?").get(req.user.id));
});

app.get("/api/categories",(req,res)=>{
  const rows=db.prepare("SELECT category,COUNT(*) count FROM listings WHERE status='active' GROUP BY category").all();
  res.json(rows);
});
app.get("/api/listings",optionalAuth,(req,res)=>{
  const {q="",category="",city="",sort="popular",limit=40}=req.query;
  let sql=`SELECT l.*,u.name seller,
    EXISTS(SELECT 1 FROM favorites f WHERE f.user_id=? AND f.listing_id=l.id) is_favorite
    FROM listings l JOIN users u ON u.id=l.user_id WHERE l.status='active'`;
  const params=[req.user?.id||0];
  if(q){sql+=" AND (l.title LIKE ? OR l.description LIKE ? OR l.city LIKE ?)";const s="%"+q+"%";params.push(s,s,s)}
  if(category){sql+=" AND l.category=?";params.push(category)}
  if(city){sql+=" AND l.city LIKE ?";params.push("%"+city+"%")}
  sql+=sort==="cheap"?" ORDER BY l.price ASC":sort==="expensive"?" ORDER BY l.price DESC":" ORDER BY l.created_at DESC";
  sql+=" LIMIT ?";params.push(Math.min(Number(limit)||40,100));
  res.json(db.prepare(sql).all(...params));
});
app.get("/api/listings/:id",(req,res)=>{
  const row=db.prepare(`SELECT l.*,u.name seller,u.email seller_email FROM listings l JOIN users u ON u.id=l.user_id WHERE l.id=? AND l.status='active'`).get(req.params.id);
  if(!row)return res.status(404).json({error:"Объявление не найдено"});
  res.json(row);
});
app.post("/api/listings",auth,upload.single("image"),(req,res)=>{
  const {title,description="",price,city="Россия",category="Другое"}=req.body;
  if(!title||!price||Number(price)<0)return res.status(400).json({error:"Название и корректная цена обязательны"});
  const image=req.file?"/uploads/"+req.file.filename:null;
  const info=db.prepare("INSERT INTO listings(user_id,title,description,price,city,category,image) VALUES(?,?,?,?,?,?,?)")
    .run(req.user.id,title,description,Number(price),city,category,image);
  res.status(201).json(db.prepare("SELECT * FROM listings WHERE id=?").get(info.lastInsertRowid));
});
app.delete("/api/listings/:id",auth,(req,res)=>{
  const row=db.prepare("SELECT * FROM listings WHERE id=?").get(req.params.id);
  if(!row)return res.status(404).json({error:"Не найдено"});
  if(row.user_id!==req.user.id && req.user.role!=="admin")return res.status(403).json({error:"Нет доступа"});
  db.prepare("UPDATE listings SET status='deleted' WHERE id=?").run(req.params.id);
  res.json({ok:true});
});
app.post("/api/listings/:id/favorite",auth,(req,res)=>{
  const exists=db.prepare("SELECT 1 FROM favorites WHERE user_id=? AND listing_id=?").get(req.user.id,req.params.id);
  if(exists) db.prepare("DELETE FROM favorites WHERE user_id=? AND listing_id=?").run(req.user.id,req.params.id);
  else db.prepare("INSERT OR IGNORE INTO favorites(user_id,listing_id) VALUES(?,?)").run(req.user.id,req.params.id);
  res.json({favorite:!exists});
});
app.get("/api/favorites",auth,(req,res)=>{
  res.json(db.prepare(`SELECT l.* FROM listings l JOIN favorites f ON f.listing_id=l.id WHERE f.user_id=? AND l.status='active' ORDER BY f.created_at DESC`).all(req.user.id));
});
app.post("/api/messages",auth,(req,res)=>{
  const {receiverId,listingId,body}=req.body;
  if(!receiverId||!body)return res.status(400).json({error:"Получатель и сообщение обязательны"});
  const info=db.prepare("INSERT INTO messages(sender_id,receiver_id,listing_id,body) VALUES(?,?,?,?)").run(req.user.id,receiverId,listingId||null,body);
  res.status(201).json(db.prepare("SELECT * FROM messages WHERE id=?").get(info.lastInsertRowid));
});
app.get("/api/messages",auth,(req,res)=>{
  res.json(db.prepare(`SELECT m.*,s.name sender_name,r.name receiver_name,l.title listing_title
    FROM messages m JOIN users s ON s.id=m.sender_id JOIN users r ON r.id=m.receiver_id
    LEFT JOIN listings l ON l.id=m.listing_id
    WHERE m.sender_id=? OR m.receiver_id=? ORDER BY m.created_at DESC`).all(req.user.id,req.user.id));
});
app.get("/api/admin/stats",auth,(req,res)=>{
  if(req.user.role!=="admin")return res.status(403).json({error:"Только для администратора"});
  res.json({
    users:db.prepare("SELECT COUNT(*) count FROM users").get().count,
    listings:db.prepare("SELECT COUNT(*) count FROM listings WHERE status='active'").get().count,
    messages:db.prepare("SELECT COUNT(*) count FROM messages").get().count,
    favorites:db.prepare("SELECT COUNT(*) count FROM favorites").get().count
  });
});
app.get("/api/health",(req,res)=>res.json({ok:true,service:"volo",time:new Date().toISOString()}));

app.get("*",(req,res)=>{
  if(req.path.startsWith("/api/")) return res.status(404).json({error:"API route not found"});
  res.sendFile(path.join(ROOT,"index.html"));
});
app.listen(PORT,()=>console.log(`volo запущен: http://localhost:${PORT}`));
